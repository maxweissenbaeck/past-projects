import { Component } from '@angular/core';
import {AuthService} from "./services/auth.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'iSong';
    email = 'mmiller@example.net';
    password = 'secret';
    user = null;

    constructor(private auth: AuthService, private router: Router) {
    }

    login(): void {
        this.auth
            .login(this.email, this.password)
            .then(success => {
                if (success) {
                    this.user = this.email;
                    this.router.navigateByUrl('/list');
                } else {
                    this.logout();
                }
            });
    }

    logout(): void {
        this.auth.logout();

        delete this.user;
        delete this.email;
        delete this.password;

        this.router.navigateByUrl('/');
    }
}
