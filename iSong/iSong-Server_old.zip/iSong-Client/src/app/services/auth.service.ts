import { Injectable } from '@angular/core';
import {Http, Headers} from "@angular/http";

@Injectable()
export class AuthService {

    private API_URL = "http://localhost:8000/api/auth";

    public user: string;
    public token: string;

    constructor(private http: Http) {
    }

    login(email: string, password: string): Promise<boolean> {
        return this.http
            .post(this.API_URL, { email: email, password: password })
            .toPromise()
            .then(response => {
                this.user = email;
                this.token = response.json().token;
                console.log('token', this.token);
                return true;
            })
            .catch(response => {
                this.logout();
                console.error('error', response.json());
                return false;
            });
    }

    logout(): void {
        delete this.token;
        delete this.user;
    }

    getHeaders():Headers {
        return function(that) {
            let headers = new Headers();

            headers.append("Content-type", "application/json");
            headers.append("Authorization", `Bearer ${that.token}`);

            return headers;
        }(this);
    }
}
