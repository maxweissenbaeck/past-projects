import { Injectable } from '@angular/core';
import {Http} from "@angular/http";
import {Song} from "../models/song";
import 'rxjs/add/operator/toPromise';
import {AuthService} from "./auth.service";

@Injectable()
export class SongService {

  API_URL:string="http://localhost:8000/api/songs";

  constructor(private http: Http, private auth: AuthService) { }

  getSongs(page){
    return this.http
        .get(this.API_URL + '?page=' + page,
            { headers: this.auth.getHeaders() }
        )
        .toPromise()
        .then(response => {
            return response.json();
        });
  }

  getSong(id:number){
      return this.http
          .get(this.API_URL + "/" + id,
              {headers: this.auth.getHeaders()})
          .toPromise()
          .then(response => {
              return response.json();
          });
  }

  createSong(song:Song){
      return this.http
          .post(this.API_URL, song, {headers:this.auth.getHeaders()})
          .toPromise()
          .then(response => response);
  }

  updateSong(song:Song){
    this.http
        .put(this.API_URL + "/" + song.id, song,
            {headers: this.auth.getHeaders()})
        .toPromise()
        .then(response => response.json());
  }

  deleteSong(id:number){
    return this.http
        .delete(this.API_URL + "/" + id, {headers: this.auth.getHeaders()})
        .toPromise()
        .then(response => console.log(response));
  }
}
