import { Component, OnInit } from '@angular/core';
import {SongService} from "../../services/song.service";

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  private response;
  private current = 1;

  constructor(private ss: SongService) { }

  ngOnInit() {
    this.getSongs();
  }

  getSongs() {
      this.ss
          .getSongs(this.current)
          .then(response => {
              this.response = response;
              this.current = response.current_page;
          });
  }

    prev() {
        if(this.current > 1) {
            this.current--;
            this.getSongs();
        }
    }

    next() {
        if(this.current < this.response.last_page) {
            this.current++;
            this.getSongs();
        }
    }

    first() {
        this.current = 1;
        this.getSongs();
    }

    last() {
        this.current = this.response.last_page;
        this.getSongs();
    }
}
