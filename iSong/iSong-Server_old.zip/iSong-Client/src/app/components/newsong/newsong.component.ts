import { Component, OnInit } from '@angular/core';
import {SongService} from "../../services/song.service";
import {Song} from "../../models/song";
import {Router} from "@angular/router";

@Component({
  selector: 'app-newsong',
  templateUrl: './newsong.component.html',
  styleUrls: ['./newsong.component.css']
})
export class NewsongComponent implements OnInit {

  public newSong: Song = new Song();
  public songs: Song[];

  constructor(private ss: SongService, private router: Router) { }

  ngOnInit() {
  }

  createSong() {
    return this.ss
        .createSong(this.newSong)
        .then(response => {
            console.log('new song created');
            this.router.navigate(['/list'])
        });
  }

  upload(event) {
      let reader = new FileReader();
      let file = event.target.files[0];
      console.log(event);

      reader.onloadend = () => {
          this.newSong.data = reader.result;
      };

      reader.readAsDataURL(file);
  }
}
