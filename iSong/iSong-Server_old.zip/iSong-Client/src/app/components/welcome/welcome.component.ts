import { Component, OnInit } from '@angular/core';
import {Http} from "@angular/http";

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  public loggedin: boolean = false;
  public email: string;
  public password: string;
  API_URL:string = "http://localhost:8000/api/auth";

  constructor(private http: Http) { }

  ngOnInit() {
  }
/*
  logIn(){
    this.http
        .post(this.API_URL, {
          email: this.email,
          password: this.password
        })
        .toPromise()
        .then(response => console.log(response));
        .then(function(response) {
            if(response == 'token') {
                this.loggedin = true;
            }
        });
  }*/
}
