import { Component, OnInit } from '@angular/core';
import {SongService} from "../../services/song.service";
import {ActivatedRoute, Router} from "@angular/router";
import {Song} from "../../models/song";

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  public song: Song;

  constructor(private ss: SongService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.route.params.subscribe(
        (params) => {
          this.getSong(params['id']);
        }
    )
  }

  getSong(id:number){
    this.ss
        .getSong(id)
        .then(response => this.song = response);
  }

  updateSong(){
    this.ss
        .updateSong(this.song);
      this.router.navigateByUrl('/list');
  }

  deleteSong(id:number){
    this.ss
        .deleteSong(id);
      this.router.navigateByUrl('/list');
  }

  upload(event) {
      let reader = new FileReader();
      let file = event.target.files[0];
      console.log(event);

      reader.onloadend = () => {
          this.song.data = reader.result;
      };

      reader.readAsDataURL(file);
    }
}
