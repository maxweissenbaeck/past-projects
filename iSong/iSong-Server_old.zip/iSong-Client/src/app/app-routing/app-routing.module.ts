import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule, Routes} from "@angular/router";
import {WelcomeComponent} from "../components/welcome/welcome.component";
import {ListComponent} from "../components/list/list.component";
import {DetailComponent} from "../components/detail/detail.component";
import {NewsongComponent} from "../components/newsong/newsong.component";

const routes: Routes = [
    {path: '', component: WelcomeComponent},
    {path: 'list', component: ListComponent},
    {path: 'newSong', component: NewsongComponent},
    {path: 'detail/:id', component: DetailComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
