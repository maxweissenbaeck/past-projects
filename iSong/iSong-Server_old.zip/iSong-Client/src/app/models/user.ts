export class User {
    firstname:string;
    lastname:string;
    email:string;
    password:string;
    avatar:any;
}
