export class Song {
    id:number;
    title:string;
    length:number;
    artist:string;
    data:any;
}
