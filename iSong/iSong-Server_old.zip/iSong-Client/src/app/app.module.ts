import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { ListComponent } from './components/list/list.component';
import { DetailComponent } from './components/detail/detail.component';
import { NewsongComponent } from './components/newsong/newsong.component';
import {AppRoutingModule} from "./app-routing/app-routing.module";
import {SongService} from "./services/song.service";
import {FormsModule} from "@angular/forms";
import {HttpModule} from "@angular/http";
import {AuthService} from "./services/auth.service";

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    ListComponent,
    DetailComponent,
    NewsongComponent,
  ],
  imports: [
    BrowserModule,
      AppRoutingModule,
      HttpModule,
      FormsModule
  ],
  providers: [SongService, AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
